# Set working directory (replace with your actual path)
setwd("C:\\Users\\Dell\\Desktop\\IT24101211")

# Import the dataset
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

# Check the structure of the data
str(Delivery_Times)
head(Delivery_Times)

fix(Delivery_Times)
attach(Delivery_Times)

# Create histogram with specified parameters
histogram <- hist(Delivery_Times$Delivery_Time_.minutes., breaks = seq(20, 70, 
                                              length.out = 10), right = FALSE,  
                                              main = "Histogram of Delivery Times")



# Extract breaks and frequencies from the histogram
breaks <- histogram$breaks
freq <- histogram$counts

# Calculate cumulative frequencies
cum_freq <- cumsum(freq)

# Create cumulative frequency with initial value 0
new_cum_freq <- c(0, cum_freq)

# Create ogive plot
plot(breaks, new_cum_freq, 
     type = "o", 
     pch = 16,
     col = "red",
     main = "Cumulative Frequency Polygon (Ogive) of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     xlim = c(20, 70),
     ylim = c(0, max(new_cum_freq) + 5))

# Add grid lines
grid()

# Add labels to data points
text(breaks, new_cum_freq, labels = new_cum_freq, pos = 3, cex = 0.8)

# Set working directory
setwd("D:/YourFolderPath/ITYourRegistrationNumber")

# Step 1: Import the dataset
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

# Step 2: Create histogram
histogram <- hist(Delivery_Times$DeliveryTime, 
                  breaks = seq(20, 70, length.out = 10),
                  right = FALSE,
                  main = "Histogram of Delivery Times",
                  xlab = "Delivery Time (minutes)",
                  ylab = "Frequency",
                  col = "lightblue",
                  border = "black",
                  xlim = c(20, 70))

# Step 3: Comment on shape (to be written in Word document)
# The distribution appears to be...

# Step 4: Create ogive
breaks <- histogram$breaks
freq <- histogram$counts
cum_freq <- cumsum(freq)
new_cum_freq <- c(0, cum_freq)

plot(breaks, new_cum_freq, 
     type = "o", 
     pch = 16,
     col = "red",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     xlim = c(20, 70),
     ylim = c(0, max(new_cum_freq) + 5))
grid()
text(breaks, new_cum_freq, labels = new_cum_freq, pos = 3, cex = 0.8)

