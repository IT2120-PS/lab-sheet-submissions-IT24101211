setwd("C:\\Users\\Dell\\Desktop\\Lab 06-20250902")
#  Exercise
# part 01
# i
# Binomial Distibution
# Here, rondom variable X has binomial distibution with n=50 and p=0.85

# ii
1-pbinom(46,50,0.85)

# part 02
# i
# X = number of customer call received in an hour

# ii
# poisson distribution
# Here, random variable X has poisson distribution with lambda = 12

# iii
dpois(15,12)






